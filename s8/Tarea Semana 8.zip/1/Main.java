// import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		// Scanner input = new Scanner(System.in);

		for (int i = 0; i < 20; i++) {
			System.out.println(i + 1);
		}
	}
}
