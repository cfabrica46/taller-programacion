# Proyecto-Final (BETA)

---
2 posibles login, (doctor, paciente)

paciente se identifica con DNI

doctor se identifica con DNI y contraseña
---

---
En caso de ser paciente, se podra
	- ver doctores
	- ver citas disponibles por especialidad
	- agendar cita
	- reagencar cita
	- cancelar cita
	- ver mis citas programadas
---

---
En caso de ser doctor, se podra
	- ver mis citas
	- Añadir una cita libre
---
